#ifndef _LAYOUT6_HPP_
#define _LAYOUT6_HPP_

#include "../maps.hpp"

Room* layout6();

#endif  // _LAYOUT6_HPP_