#ifndef _LAYOUT10_HPP_
#define _LAYOUT10_HPP_

#include "../maps.hpp"

Room* layout10();

#endif  // _LAYOUT10_HPP_