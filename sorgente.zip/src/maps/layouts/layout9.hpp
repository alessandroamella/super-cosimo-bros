#ifndef _LAYOUT9_HPP_
#define _LAYOUT9_HPP_

#include "../maps.hpp"

Room* layout9();

#endif  // _LAYOUT9_HPP_