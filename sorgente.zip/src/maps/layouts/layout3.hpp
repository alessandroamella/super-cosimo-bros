#ifndef _LAYOUT3_HPP_
#define _LAYOUT3_HPP_

#include "../maps.hpp"

Room* layout3();

#endif  // _LAYOUT3_HPP_
