#ifndef _LAYOUT2_HPP_
#define _LAYOUT2_HPP_

#include "../maps.hpp"

Room* layout2();

#endif  // _LAYOUT2_HPP_
