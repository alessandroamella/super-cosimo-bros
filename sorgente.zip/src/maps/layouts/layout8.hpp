#ifndef _LAYOUT8_HPP_
#define _LAYOUT8_HPP_

#include "../maps.hpp"

Room* layout8();

#endif  // _LAYOUT8_HPP_