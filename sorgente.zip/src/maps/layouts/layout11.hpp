#ifndef _LAYOUT11_HPP_
#define _LAYOUT11_HPP_

#include "../maps.hpp"

Room* layout11();

#endif  // _LAYOUT11_HPP_