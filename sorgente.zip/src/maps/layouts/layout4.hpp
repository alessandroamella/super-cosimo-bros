#ifndef _LAYOUT4_HPP_
#define _LAYOUT4_HPP_

#include "../maps.hpp"

Room* layout4();

#endif  // _LAYOUT4_HPP_
