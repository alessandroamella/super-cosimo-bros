#ifndef _LAYOUT7_HPP_
#define _LAYOUT7_HPP_

#include "../maps.hpp"

Room* layout7();

#endif  // _LAYOUT7_HPP_