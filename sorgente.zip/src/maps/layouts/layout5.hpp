#ifndef _LAYOUT5_HPP_
#define _LAYOUT5_HPP_

#include "../maps.hpp"

Room* layout5();

#endif  // _LAYOUT5_HPP_
