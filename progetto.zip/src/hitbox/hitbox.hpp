#include "../staticentity/staticentity.hpp"

bool collides(StaticEntity* a, StaticEntity* b);