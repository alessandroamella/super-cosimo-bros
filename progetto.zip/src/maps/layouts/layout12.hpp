#ifndef _LAYOUT12_HPP_
#define _LAYOUT12_HPP_

#include "../maps.hpp"

Room* layout12();

#endif  // _LAYOUT12_HPP_