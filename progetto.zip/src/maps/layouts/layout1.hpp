#ifndef _LAYOUT1_HPP_
#define _LAYOUT1_HPP_

#include "../maps.hpp"

Room* layout1();

#endif  // _LAYOUT1_HPP_
